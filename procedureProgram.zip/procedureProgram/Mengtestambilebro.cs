using System;
namespace procedureProgram
{
    class Mengtestambilebro
    {
        private static void Okbang()
        {
            Console.WriteLine();
        }

        private static void Mogasehatselalu()
        {
            Console.WriteLine();
        }

    }
}