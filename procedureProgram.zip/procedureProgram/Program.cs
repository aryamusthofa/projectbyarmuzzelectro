﻿using System;
namespace procedureProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            Procedure dasar = new Procedure();
            dasar.Ampunpuh();
            Console.ReadLine();
        }
    }
}