using System;
namespace procedureProgram
{
    class Procedure
    {
        private static void Kerjabagus()
        {
            Console.WriteLine("\n \n -------------------------------------------");

        }

        private static void Wowkeren()
        {
            Console.WriteLine("\n \n WELCOME GUYS HOW ARE YOU DOING?");
            Console.WriteLine("\n \n SEE YOU IN TODAY GOOD LUCK");
        }

        public void Ampunpuh()
        {
            Kerjabagus();
            Wowkeren();
            Kerjabagus();
            Console.WriteLine();
            Console.ReadLine();
        }

    }
}